import { isLunaAvailable, lunaRequest } from './luna';

export const INTEGRATIONS = {
  nuvio: {
    appId: 'space.nuvio.native.legacy',
    name: 'Nuvio',
  },
  twitch: {
    appId: 'twitch.betterfrz.v3',
    name: 'BetterTwitch',
  },
} as const;

export type IntegrationId = keyof typeof INTEGRATIONS;

export function launchIntegration(id: IntegrationId, onFailure?: (message: string) => void): void {
  if (!isLunaAvailable()) {
    onFailure?.('webOS application service is unavailable');
    return;
  }

  const integration = INTEGRATIONS[id];
  lunaRequest('luna://com.webos.applicationManager', {
    method: 'launch',
    parameters: { id: integration.appId },
    onFailure: (response) => {
      onFailure?.(response.errorText || `Unable to launch ${integration.name}`);
    },
  });
}

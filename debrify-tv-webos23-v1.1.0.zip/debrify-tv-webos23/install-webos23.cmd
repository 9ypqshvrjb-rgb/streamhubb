@echo off
setlocal
cd /d %~dp0
if "%1"=="" (
  echo Gebruik: install-webos23.cmd NAAM-VAN-JE-ARES-DEVICE
  echo Voorbeeld: install-webos23.cmd tv
  exit /b 1
)
ares-package debrify-tv debrify-service -o .
if errorlevel 1 exit /b 1
for %%F in (com.debrify.tv_*.ipk) do set IPK=%%F
if not defined IPK (
  echo Geen IPK gevonden.
  exit /b 1
)
ares-install -d %1 "%IPK%"
ares-launch -d %1 com.debrify.tv

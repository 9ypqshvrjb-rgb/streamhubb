DEBRIFY TV - webOS 23
=====================

Dit pakket gebruikt je bestaande Ares/Ares CLI-verbinding.

1. Controleer je device-naam:
   ares-setup-device --list

2. macOS/Linux:
   ./install-webos23.sh tv

   Windows:
   install-webos23.cmd tv

De scripts packagen de webapp + JS-service samen in één IPK en installeren/launcheren die op de TV.

App ID:     com.debrify.tv
Service ID: com.debrify.tv.service
Versie:     1.1.0

De service luistert lokaal op de TV op poort 8765 voor de telefoon-koppeling.

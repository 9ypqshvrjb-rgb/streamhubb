const Service=require('webos-service'),http=require('http'),os=require('os');
const svc=new Service('com.debrify.tv.service');let q=[],srv,keep;
const PORT=8765;
const json=(res,obj)=>{res.setHeader('Content-Type','application/json; charset=utf-8');res.end(JSON.stringify(obj));};
const PAGE=`<!DOCTYPE html><html lang=nl><meta name=viewport content="width=device-width,initial-scale=1"><title>Debrify TV</title><style>body{font:18px system-ui;background:#121826;color:#eef1f7;padding:24px;max-width:560px;margin:auto}h1{color:#f5b83d}input,button{width:100%;padding:14px;margin:6px 0 14px;border-radius:12px;border:0;font:inherit}input{background:#1b2335;color:#fff}button{background:#f5b83d;font-weight:700}</style><h1>Debrify TV</h1><label>Stremio- of Nuvio-addon-URL</label><input id=a placeholder="https://…/manifest.json"><button onclick="s('addon','a')">Addon toevoegen</button><label>M3U-afspeellijst (IPTV)</label><input id=m placeholder="http://…/lijst.m3u"><button onclick="s('m3u','m')">Lijst opslaan</button><label>Tv-gids (XMLTV-URL)</label><input id=e placeholder="http://…/epg.xml"><button onclick="s('epg','e')">Gids opslaan</button><p id=r></p><script>async function s(t,i){const v=document.getElementById(i).value.trim();if(!v)return;await fetch('/',{method:'POST',body:JSON.stringify({t:t,v:v})});document.getElementById(i).value='';document.getElementById('r').textContent='Verstuurd naar je tv ✓'}</script>`;
svc.register('start',m=>{
 if(!srv){srv=http.createServer((req,res)=>{res.setHeader('Access-Control-Allow-Origin','*');
  if(req.url=='/health'){return json(res,{ok:true,service:'com.debrify.tv.service'});}
   if(req.url=='/pull'){return json(res,q.splice(0,q.length));}
  if(req.method=='POST'){let b='';req.on('data',d=>{if(b.length<65536)b+=d});req.on('end',()=>{try{const x=JSON.parse(b);if(x&&['addon','m3u','epg'].includes(x.t)&&typeof x.v=='string'&&x.v.length<8192)q.push(x);json(res,{ok:true})}catch(e){res.statusCode=400;json(res,{ok:false})}});return}
  res.setHeader('Content-Type','text/html;charset=utf-8');res.end(PAGE)}).listen(PORT,'0.0.0.0');
  svc.activityManager.create('keepAlive',a=>{keep=a})}
 const ip=[].concat(...Object.values(os.networkInterfaces())).find(i=>i.family=='IPv4'&&!i.internal);
 m.respond({returnValue:true,ip:ip&&ip.address})});

#!/bin/sh
set -e
cd "$(dirname "$0")"
DEVICE="${1:-tv}"
rm -f com.debrify.tv_*.ipk
ares-package ./debrify-tv ./debrify-service -o .
IPK=$(ls com.debrify.tv_*.ipk | head -n 1)
ares-install -d "$DEVICE" "$IPK"
ares-launch -d "$DEVICE" com.debrify.tv
